## next steps:

- test rate limits (highest priority)
- add tests for like, unlike, comment, uncomment
- improve documentation
- removing slugify dependency (the less dependencies the better, only used on one spot instagram.py line 74)
- simplify code while keeping functionality and readability
- add private message functionality
