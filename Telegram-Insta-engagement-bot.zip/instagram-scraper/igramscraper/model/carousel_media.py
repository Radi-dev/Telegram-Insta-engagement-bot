class CarouselMedia:

    def __init__(self):
        self.__type = ''
        self.__image_low_resolution_url = ''
        self.__image_thumbnail_url = ''
        self.__image_standard_resolution_url = ''
        self.__image_high_resolution_url = ''
        self.__video_low_resolution_url = ''
        self.__video_standard_resolution_url = ''
        self.__video_low_bandwidth_url = ''
        self.__video_views = ''

