Because of issues faced with pip install on windows 10, I have included this folder for manual installation.
Note that it's not useful if pip install igramscraper works for you. If not, then go ahead and cd into this folder, then run
"python setup.py install"
